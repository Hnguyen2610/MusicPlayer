package com.example.music_app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import com.example.music_app.model.User;

public class UserDAO {
    DBHelper dbHelper;
    private static SQLiteDatabase sqliteDa;

    public UserDAO(Context context) {
        dbHelper = new DBHelper(context);
        sqliteDa = dbHelper.getWritableDatabase();
    }
    public ArrayList<User> GetDSS(){
        ArrayList<User> list = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = dbHelper.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM user",null);
        if(cursor.getCount() > 0){
            cursor.moveToFirst();
            do{
                User user = new User();
                user.setUser(cursor.getString(0));
                user.setPass(cursor.getString(1));
                list.add(user);
            }while (cursor.moveToNext());
        }
        return list;
    }
    public long Themuser(User user){
        SQLiteDatabase sqLiteDatabase = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id_user", user.getUser());
        contentValues.put("pass_user", user.getPass());

        return sqLiteDatabase.insert("tbl_user",null,contentValues);
    }
    public boolean checkLogin(String tentv,String mk){

        SQLiteDatabase sqLiteDatabase = dbHelper.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM tbl_user WHERE id_user = ? AND pass_user = ? ",
                new String[]{tentv,mk});
        if(cursor.getCount() > 0){
            return  true;
        }
        else {
            return false;
        }
    }
}
